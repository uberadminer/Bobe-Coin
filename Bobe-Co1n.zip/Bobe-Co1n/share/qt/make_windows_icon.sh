#!/bin/bash
# create multiresolution windows icon
ICON_SRC=../../src/qt/res/icons/bobecoin.png
ICON_DST=../../src/qt/res/icons/bobecoin.ico
convert ${ICON_SRC} -resize 16x16 bobecoin-16.png
convert ${ICON_SRC} -resize 32x32 bobecoin-32.png
convert ${ICON_SRC} -resize 48x48 bobecoin-48.png
convert bobecoin-16.png bobecoin-32.png bobecoin-48.png ${ICON_DST}

