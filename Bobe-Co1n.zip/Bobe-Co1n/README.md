# Bobecoin
![Image](https://raw.githubusercontent.com/uberadminer/Bobe-Coin/master/src/qt/res/images/splash.png)
Bobecoin is a cryptocurrency based on the following principles:

1. The fostering of a free, and BEEF-based market.
2. The empirical certainty of the falsehood of all things. 
3. The abhorrent abscence of BEEF in the majority of crypocurrencies today.
4. The fact that (everyone) loves beef.